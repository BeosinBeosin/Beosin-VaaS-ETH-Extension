var program = require('commander')

var solc = require('./solc/')
var fs = require("fs")

program
    .option('-f, --file <type>', 'file path')

program.parse(process.argv);
  console.log(program.file)
 var input = fs.readFileSync(program.file).toString()
// console.log(input)
 // Setting 1 as second paramateractivates the optimiser
 var output = solc.compile(input)
 console.log(JSON.stringify(output))
 /*for (var contractName in output.contracts) {
   // code and ABI
    console.log(output.contracts[contractName].functionHashes)
  // console.log(contractName + ': ' + output.contracts[contractName].bytecode)
//   console.log(contractName + ': ' + output.contracts[contractName].interface)
}*/