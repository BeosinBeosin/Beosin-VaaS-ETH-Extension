import magic

######################################
# Unresolvable Call Target
######################################


class UnresolvableCallTarget(magic.SimProcedure):
    NO_RET = False

    def run(self):#pylint: disable=arguments-differ
        return
