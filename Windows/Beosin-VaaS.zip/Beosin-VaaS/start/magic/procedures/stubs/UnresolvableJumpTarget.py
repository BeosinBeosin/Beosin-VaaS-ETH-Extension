import magic

######################################
# Unresolvable Jump Target
######################################


class UnresolvableJumpTarget(magic.SimProcedure):
    NO_RET = True

    def run(self):#pylint: disable=arguments-differ
        return
