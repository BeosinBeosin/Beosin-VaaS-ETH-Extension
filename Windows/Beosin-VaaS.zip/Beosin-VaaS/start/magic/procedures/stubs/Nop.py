import magic

######################################
# Doing nothing
######################################


class Nop(magic.SimProcedure):
    def run(self):
        pass
