import magic

######################################
# Path terminator
######################################


class PathTerminator(magic.SimProcedure):
    NO_RET = True

    def run(self):
        return
